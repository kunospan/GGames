package com.example.ggames

data class TikTakToeState (
    val playerCounterCircle: Int = 0,
    val playerCounterCross: Int = 0,
    val drawCount: Int = 0,
    val playerTurnText: String = "Player O",
    val BoardCell: BoardCellCurrent = BoardCellCurrent.Circle,
    val gameEndingType: gameEnding = gameEnding.None,
    val winnedState: Boolean = false
)
enum class BoardCellCurrent{
    Circle, Cross, None
}

enum class gameEnding{
    Line1Condition(),
    Line2Condition(),
    Line3Condition(),
    Line4Condition(),
    Line5Condition(),
    Line6Condition(),
    Line7Condition(),
    Line8Condition(),
    Line9Condition(),
    None
}