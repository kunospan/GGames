package com.example.ggames

import android.app.GameState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

class TicTacToeViewModel: ViewModel() {

    var state by mutableStateOf(TikTakToeState())

    val boardItems: MutableMap<Int, BoardCellCurrent> = mutableMapOf(
        1 to BoardCellCurrent.None,
        2 to BoardCellCurrent.None,
        3 to BoardCellCurrent.None,
        4 to BoardCellCurrent.None,
        5 to BoardCellCurrent.None,
        6 to BoardCellCurrent.None,
        7 to BoardCellCurrent.None,
        8 to BoardCellCurrent.None,
        9 to BoardCellCurrent.None
    )
    fun onAction(action: UserAction){
        when(action){
            is UserAction.BoardClick -> {
                addValueToBoard(action.cellNo)
            }
            UserAction.PlayAgainButton -> {
                gameReset()
            }
        }
    }

    private fun gameReset() {
        boardItems.forEach { (i, _) ->
            boardItems[i] = BoardCellCurrent.None
        }
        state = state.copy(
            playerTurnText = "Player O",
            BoardCell = BoardCellCurrent.Circle,
            gameEndingType = gameEnding.None,
            winnedState = false
        )
    }//resets the board to all values being none

    private fun addValueToBoard(cellNo: Int) {
        if (boardItems[cellNo] != BoardCellCurrent.None){
            return
        }//user has to tap other cell if not none
        if (state.BoardCell == BoardCellCurrent.Circle){
            boardItems[cellNo] = BoardCellCurrent.Circle
            if (checkVictory(BoardCellCurrent.Circle)){
                state = state.copy(
                    playerTurnText = "Player O wins",
                    playerCounterCircle = state.playerCounterCircle +1,
                    BoardCell = BoardCellCurrent.None,
                    winnedState = true

                )
            }
            if (boardFull()){
                state = state.copy(
                    playerTurnText=("Draw"),
                    drawCount = state.drawCount + 1
                )
            }else {
                state = state.copy(
                    playerTurnText=("Player X"),
                    BoardCell = BoardCellCurrent.Cross
                )
            }
            //after circle is assigned as value display text and current player turn change
        }//if it is the Cirle players turn this will assign the circle to this specific cellno
        else if (state.BoardCell == BoardCellCurrent.Cross){
            boardItems[cellNo] = BoardCellCurrent.Cross
            if (checkVictory(BoardCellCurrent.Cross)){
                state = state.copy(
                    playerTurnText = "Player X wins",
                    playerCounterCross = state.playerCounterCross +1,
                    BoardCell = BoardCellCurrent.None,
                    winnedState = true

                )
            }
            if (boardFull()){
                state = state.copy(
                    playerTurnText=("Draw"),
                    drawCount = state.drawCount + 1
                )
            } else {
                state = state.copy(
                    playerTurnText = "Player O",
                    BoardCell = BoardCellCurrent.Circle
                )//same as before just with the player x's turn
            }
        }
    }

    private fun checkVictory(boardValue: BoardCellCurrent): Boolean {
        when{
            boardItems[1] == boardItems[2] && boardValue == boardValue && boardItems[3]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line1Condition)
                return true
            }
            boardItems[4] == boardItems[5] && boardValue == boardValue && boardItems[6]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line2Condition)
                return true
            }
            boardItems[7] == boardItems[8] && boardValue == boardValue && boardItems[9]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line3Condition)
                return true
            }
            boardItems[1] == boardItems[4] && boardValue == boardValue && boardItems[7]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line4Condition)
                return true
            }
            boardItems[2] == boardItems[5] && boardValue == boardValue && boardItems[8]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line5Condition)
                return true
            }
            boardItems[3] == boardItems[6] && boardValue == boardValue && boardItems[9]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line6Condition)
                return true
            }
            boardItems[1] == boardItems[5] && boardValue == boardValue && boardItems[9]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line7Condition)
                return true
            }
            boardItems[3] == boardItems[5] && boardValue == boardValue && boardItems[7]== boardValue ->{
                state = state.copy(gameEndingType= gameEnding.Line8Condition)
                return true
            }
            else -> return false
        }
    }

    private fun boardFull(): Boolean{
        if (boardItems.containsValue(BoardCellCurrent.None))
            return false
        return true
    }
}