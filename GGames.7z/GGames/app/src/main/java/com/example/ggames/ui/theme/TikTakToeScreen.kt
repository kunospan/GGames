package com.example.ggames.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.integerResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ggames.TicTacToeViewModel
import com.example.ggames.UserAction

@Composable
fun TikTakToeScreen(
    viewModel: TicTacToeViewModel
//use created viewmodel
){
    val state = viewModel.state
    //following is the ui
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Player 'O': ${state.playerCounterCircle}", fontSize = 16.sp)
            Text(text = "Draw: ${state.drawCount}", fontSize = 16.sp)
            Text(text = "Player 'X': ${state.playerCounterCross}", fontSize = 16.sp)
            
        }
        Text(
            text = "TicTacToe",
            fontSize = 50.sp,
            //color =
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
                //here will come a shadow
                //
                //
            contentAlignment = Alignment.Center
        ) {
            Board()
            LazyVerticalGrid(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .aspectRatio(1f),
                columns = GridCells.Fixed(3)
            ){
                viewModel.boardItems.forEach{
                    (cellNo, BoardCellCurrent) ->
                    item {
                        Column (
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clickable() {
                                    viewModel.onAction(UserAction.BoardClick(cellNo))
                                },//whenever user clicks on cell it will call this useraction of onaction function defined in the viewmodel
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (BoardCellCurrent==com.example.ggames.BoardCellCurrent.Circle){
                                Circle()
                            }
                            else if (BoardCellCurrent==com.example.ggames.BoardCellCurrent.Cross){
                                Cross()
                            }
                        }
                    }
                }
            }
        } //this checks the cell value and inserts the needed component
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = state.playerTurnText,
                fontSize = 16.sp
            )
            Button(
                onClick = {
                          viewModel.onAction(
                              UserAction.PlayAgainButton
                          )//call function defined
                },
                shape = RoundedCornerShape(5.dp),
                elevation = ButtonDefaults.elevation(5.dp),
                colors = ButtonDefaults.buttonColors(
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = "Play Again",
                    fontSize = 16.sp
                )
            }
        }

    }
}
@Preview
@Composable
fun Prev(){
    TikTakToeScreen(
        viewModel = TicTacToeViewModel()
    )
}