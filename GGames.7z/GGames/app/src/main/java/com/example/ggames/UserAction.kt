package com.example.ggames

sealed class UserAction{
    object PlayAgainButton: UserAction()
    data class BoardClick(val cellNo: Int): UserAction()
}
